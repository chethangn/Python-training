import pyodbc
DBfile = '/GNC/Python/pydatabase/database1.mdb'
conn = pyodbc.connect('DRIVER={Microsoft Access Driver (*.mdb)};DBQ='+DBfile)
cursor = conn.cursor()
SQL = 'SELECT * FROM Projects;'

print SQL

cursor.close()
conn.close()
