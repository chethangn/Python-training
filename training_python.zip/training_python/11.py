import pandas as pd
inf = pd.read_csv('output_file.csv')
print(inf[['EmployeeName', 'Gender', 'DOJ']])
