#         row[0] == Employee ID
#         row[1] == Employee Name
#         row[5] == Gender
#         row[8] == Designation
#         row[10] == DOJ

# Importing required libraries
import csv
import numpy as np
np.set_printoptions(threshold=np.inf)

# import collections
import matplotlib.pyplot as plt
import json
import re
import datetime

# Universal declarations to be used in function and outside
seen = []
name_column = 1
uniques = []

allEmployeeData = np.array([])
allEmployeeId = []
allDates = []
slice_content_days = np.array([])
deviceLogsContent = np.array([])
sortedarray = np.array([])
# x = []
timingsLogs = np.array([])
formattedData = np.array([])
deviceLogsContent = np.array([])
formattedData = np.append(formattedData,[['EmpID','EmpName','InTime','OutTime','Date']])
formattedData = formattedData.reshape((formattedData.shape[0], 1))
formattedData = formattedData.reshape(-1, 5)
year_male_count = []
count_2011 = 0
count = 0
month = []
year = []
year_val = []
month_val = []
i = 0 

# Function for checking out if name field contains number
def num_there(s):
    return any(i.isdigit() for i in s)


# Opening a csv file
with open('Employees_file.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    for row in inf:
        if row[name_column] not in seen and not (num_there(row[1])) and not row[5] == 'Gender':
            if row[5] == 'M' or row[5] == 'male':
                row[5] = 'Male'
            if row[5] == 'F' or row[5] == 'female':
                row[5] = 'Female'
            uniques.append(row)
            seen.append(row[name_column])
            row[10] = row[10][0:8]
            year_val = row[10][6:8]
            month_val = row[10][0:2]
            year.append(year_val)
            month.append(month_val)
            if re.match(r'^Del_', row[2]):
                row[2] = row[2][4:]
            allEmployeeData = np.append(allEmployeeData,[[row[2],row[1],row[5],row[10],row[8],month_val,year_val]])
            allEmployeeData = allEmployeeData.reshape((allEmployeeData.shape[0], 1))
            allEmployeeData = allEmployeeData.reshape(-1, 7)

with open('DeviceLogs2.csv') as csvfile:
    inf1 = csv.reader(csvfile, delimiter=',')
    for row in inf1:
        if num_there(row[0]):
            datesSplicedValue = row[5][:8]
            timeSplicedValue = row[5][9:17]
            deviceLogsContent = np.append(deviceLogsContent,[[row[4],datesSplicedValue,timeSplicedValue]])
            deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
            deviceLogsContent = deviceLogsContent.reshape(-1, 3)
# print(deviceLogsContent)

# Unique Date and ID
allEmployeeDates = np.unique(deviceLogsContent[:,1])
allEmployeeID = np.unique(deviceLogsContent[:,0])

# Sorting
# x = np.sort(deviceLogsContent, axis=0)
# x = sorted(deviceLogsContent, key=lambda deviceLogsContent_entry: deviceLogsContent_entry[0],dtype=np.object)

sortedarray = deviceLogsContent[np.lexsort(np.transpose(deviceLogsContent)[::-1])]



# x = deviceLogsContent[deviceLogsContent[:,0].argsort(kind='quicksort')]

# ind = np.lexsort((deviceLogsContent[:,0],deviceLogsContent[:,1]))
# x = deviceLogsContent.argsort(axis=-1, kind='quicksort', order=None)
# deviceLogsContent.sort(key=lambda x: x[0])
# x = deviceLogsContent[deviceLogsContent[:, 0].argsort()]
# x = x.reshape((x.shape[0], 1))

# x = argsort(deviceLogsContent,axis=0,kind='quicksort')

# x = x.reshape(-1, 3)
# deviceLogsContent = np.sort(deviceLogsContent, order=['f1'], axis=0)
# x.view('i8,i8,i8').sort(order=['f1'], axis=0)
# x = deviceLogsContent[deviceLogsContent[:,0].argsort()]
# x = deviceLogsContent[deviceLogsContent[:,1].argsort()]
# print(x.shape)

# print(x)

# print(deviceLogsContent[ind],x)


# Length of dates and ID
allEmployeeDatesLength = len(allEmployeeDates)
allEmployeeIDLength = len(allEmployeeID)
lengthsortedarray = len(sortedarray)
newid = 1
update = 1
countwaste = 0
for content in range(len(sortedarray)-1):
    if sortedarray[i,0] == sortedarray[i+1,0] and sortedarray[i,1] == sortedarray[i+1,1]:
        if newid == 1 and  update == 1:
            formattedData = np.append(formattedData,[[sortedarray[i,0],'EmpName',sortedarray[i,2],sortedarray[i,2],sortedarray[i,1]]])
            formattedData = formattedData.reshape((formattedData.shape[0], 1))
            formattedData = formattedData.reshape(-1, 5)
            newid = 0
            update = 0
    if sortedarray[i,0] == sortedarray[i+1,0] and sortedarray[i,1] != sortedarray[i+1,1]:
        if update == 0 and newid == 0:
            lenformattedData = len(formattedData) - 1
            formattedData[lenformattedData,3] = sortedarray[i,2]
            newid = 1
            update = 1
    if sortedarray[i,0] != sortedarray[i+1,0] and sortedarray[i,1] == sortedarray[i+1,1]:
        if update == 0 and newid == 0:
            lenformattedData = len(formattedData) - 1
            formattedData[lenformattedData,3] = sortedarray[i,2]
            newid = 1
            update = 1
    if sortedarray[i,0] != sortedarray[i+1,0] and sortedarray[i,1] != sortedarray[i+1,1]:
        if update == 0 and newid == 0:
            lenformattedData = len(formattedData) - 1
            formattedData[lenformattedData,3] = sortedarray[i,2]
            newid = 1
            update = 1
    else:
        countwaste += 1
    i += 1
print(formattedData)
# print(sortedarray)
# print(deviceLogsContent)
# print(i)
# print(len(sortedarray))
# print(deviceLogsContent.shape)
# print(countwaste)
