#         row[0] == Employee ID
#         row[1] == Employee Name
#         row[5] == Gender
#         row[8] == Designation
#         row[10] == DOJ



# Importing required libraries
import csv
import numpy as np
# import collections
import matplotlib.pyplot as plt
import json
import re

# Universal declarations to be used in function and outside
seen = []
name_column = 1
uniques = []
c = np.array([])

# a = np.empty([300, 5])
a = np.array([])
# a= np.empty(shape=[0, n])
b = np.array([])
year_male_count = []
count_2011 = 0
count = 0
month = []
year = []
year_val = []
month_val = []

# Function for checking out if name field contains number
def num_there(s):
    return any(i.isdigit() for i in s)


# Opening a csv file
with open('Employees_file.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    for row in inf:
        if row[name_column] not in seen and not (num_there(row[1])) and not row[5] == 'Gender':
            if row[5] == 'M' or row[5] == 'male':
                row[5] = 'Male'
            if row[5] == 'F' or row[5] == 'female':
                row[5] = 'Female'
            uniques.append(row)
            seen.append(row[name_column])
            row[10] = row[10][0:8]
            year_val = row[10][6:8]
            month_val = row[10][0:2]
            year.append(year_val)
            month.append(month_val)
            if re.match(r'^Del_', row[2]):
                row[2] = row[2][4:]      
                
            a = np.append(a,[[row[2],row[1],row[5],row[10],row[8],month_val,year_val]])
            a = a.reshape((a.shape[0], 1))
            a = a.reshape(-1, 7)

            
with open('DeviceLogs1.csv') as csvfile:
    inf1 = csv.reader(csvfile, delimiter=',')
    for row in inf1:
        c = np.append(c,[[row[4],row[5]]])
        c = c.reshape((c.shape[0], 1))
        c = c.reshape(-1, 2)
with open('DeviceLogs2.csv') as csvfile:
    inf1 = csv.reader(csvfile, delimiter=',')
    for row in inf1:
        c = np.append(c,[[row[4],row[5]]])
        c = c.reshape((c.shape[0], 1))
        c = c.reshape(-1, 2)
with open('DeviceLogs3.csv') as csvfile:
    inf1 = csv.reader(csvfile, delimiter=',')
    for row in inf1:
        c = np.append(c,[[row[4],row[5]]])
        c = c.reshape((c.shape[0], 1))
        c = c.reshape(-1, 2)
with open('DeviceLogs4.csv') as csvfile:
    inf1 = csv.reader(csvfile, delimiter=',')
    for row in inf1:
        c = np.append(c,[[row[4],row[5]]])
        c = c.reshape((c.shape[0], 1))
        c = c.reshape(-1, 2)
with open('DeviceLogs5.csv') as csvfile:
    inf1 = csv.reader(csvfile, delimiter=',')
    for row in inf1:
        c = np.append(c,[[row[4],row[5]]])
        c = c.reshape((c.shape[0], 1))
        c = c.reshape(-1, 2)
with open('DeviceLogs6.csv') as csvfile:
    inf1 = csv.reader(csvfile, delimiter=',')
    for row in inf1:
        c = np.append(c,[[row[4],row[5]]])
        c = c.reshape((c.shape[0], 1))
        c = c.reshape(-1, 2)
with open('DeviceLogs7.csv') as csvfile:
    inf1 = csv.reader(csvfile, delimiter=',')
    for row in inf1:
        c = np.append(c,[[row[4],row[5]]])
        c = c.reshape((c.shape[0], 1))
        c = c.reshape(-1, 2)




            

    
   
        
        
# myFile = open('example2.csv', 'w')
# with myFile:
#     writer = csv.writer(myFile)
#     writer.writerows(a)
     







male_total = np.sum(a[:,2] == 'Male')
female_total = np.sum(a[:,2] == 'Female')


year_2011 = np.sum(a[:,6] == '11')
year_2012 = np.sum(a[:,6] == '12')
year_2013 = np.sum(a[:,6] == '13')
year_2014 = np.sum(a[:,6] == '14')
year_2015 = np.sum(a[:,6] == '15')
year_2016 = np.sum(a[:,6] == '16')
year_2017 = np.sum(a[:,6] == '17')



year_2011_male = a[:,1][np.logical_and(a[:,6] == '11', a[:,2] == 'Male')].size
year_2012_male = a[:,1][np.logical_and(a[:,6] == '12', a[:,2] == 'Male')].size
year_2013_male = a[:,1][np.logical_and(a[:,6] == '13', a[:,2] == 'Male')].size
year_2014_male = a[:,1][np.logical_and(a[:,6] == '14', a[:,2] == 'Male')].size
year_2015_male = a[:,1][np.logical_and(a[:,6] == '15', a[:,2] == 'Male')].size
year_2016_male = a[:,1][np.logical_and(a[:,6] == '16', a[:,2] == 'Male')].size
year_2017_male = a[:,1][np.logical_and(a[:,6] == '17', a[:,2] == 'Male')].size


year_2011_female = a[:,1][np.logical_and(a[:,6] == '11', a[:,2] == 'Female')].size
year_2012_female = a[:,1][np.logical_and(a[:,6] == '12', a[:,2] == 'Female')].size
year_2013_female = a[:,1][np.logical_and(a[:,6] == '13', a[:,2] == 'Female')].size
year_2014_female = a[:,1][np.logical_and(a[:,6] == '14', a[:,2] == 'Female')].size
year_2015_female = a[:,1][np.logical_and(a[:,6] == '15', a[:,2] == 'Female')].size
year_2016_female = a[:,1][np.logical_and(a[:,6] == '16', a[:,2] == 'Female')].size
year_2017_female = a[:,1][np.logical_and(a[:,6] == '17', a[:,2] == 'Female')].size



print("total male employee count is",male_total)
print("total female employee count is",female_total)
total_emp = male_total + female_total
print("total number of employees are",total_emp)



year_2011 = year_2011+1
print("----------------------------------------------------------------------------------------")
print("Total employee hired in 2011",year_2011)
print("Total employee hired in 2012",year_2012)
print("Total employee hired in 2013",year_2013)
print("Total employee hired in 2014",year_2014)
print("Total employee hired in 2015",year_2015)
print("Total employee hired in 2016",year_2016)
print("Total employee hired in 2017",year_2017)
print("----------------------------------------------------------------------------------------")
print("Total count per year basis")

print("Total employee in 2011",year_2011)
print("Total employee in 2012",year_2011+year_2012)
print("Total employee in 2013",year_2011+year_2012+year_2013)
print("Total employee in 2014",year_2011+year_2012+year_2013+year_2014)
print("Total employee in 2015",year_2011+year_2012+year_2013+year_2014+year_2015)
print("Total employee in 2016",year_2011+year_2012+year_2013+year_2014+year_2015+year_2016)
print("Total employee in 2017",year_2011+year_2012+year_2013+year_2014+year_2015+year_2016+year_2017)

print("-------------------------------------------------------------------------------------------")
print("Yearly based hired male count 2011", year_2011_male," Female count 2011",year_2011_female)
print("Yearly based hired male count 2012", year_2012_male," Female count 2012",year_2012_female)
print("Yearly based hired male count 2013", year_2013_male," Female count 2013",year_2013_female)
print("Yearly based hired male count 2014", year_2014_male," Female count 2014",year_2014_female)
print("Yearly based hired male count 2015", year_2015_male,"Female count 2015",year_2015_female)
print("Yearly based hired male count 2016", year_2016_male,"Female count 2016",year_2016_female)
print("Yearly based hired male count 2017", year_2017_male,"Female count 2017",year_2017_female)



total_count = [male_total,female_total,total_emp]
total_count = np.array(total_count).tolist()
yearly_count = [year_2011,year_2012,year_2013,year_2014,year_2015,year_2016,year_2017]
yearly_count = np.array(yearly_count).tolist()
yearly_male_count = [year_2011_male,year_2012_male,year_2013_male,year_2014_male,year_2015_male,year_2016_male,year_2017_male]
yearly_male_count = np.array(yearly_male_count).tolist()
year_female_count = [year_2011_female,year_2012_female,year_2013_female,year_2014_female,year_2015_female,year_2016_female,year_2017_female]
year_female_count = np.array(year_female_count).tolist()
with open('data.txt', 'w') as outfile:  
    json.dump(total_count, outfile)
    json.dump(yearly_count, outfile)
    json.dump(yearly_male_count, outfile)
    json.dump(year_female_count, outfile)

