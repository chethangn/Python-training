# import csv
# input = open('first.csv', 'rb')
# output = open('first_edit.csv', 'wb')
# writer = csv.writer(output)
# for row in csv.reader(input):
#     if row[2]!=0:
#         writer.writerow(row)
# input.close()
# output.close()

# ---------------------------------------------------------------------

# import csv

# with open("output_file.csv", "rb") as f:
#     data = list(csv.reader(f))

# with open("output_file.csv", "wb") as f:
#     writer = csv.writer(f)
#     for row in data:
#         if row[2] != "0":
#             writer.writerow(row)
# ------------------------------------------------------------------------------
# import csv
# with open('output_file.csv', 'rb') as csvfile:
#     inf = csv.reader(csvfile, delimiter=',', quotechar='|')
#     for row in inf:
#         print (' '.join(row))

import csv

with open('Employee_file.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    print(inf)
    for row in inf:
        print('1')
        if row[5] == 'M' or row[5] == 'Male' or row[5] == 'M' or row[5] == 'male' and r.match(row[10]):
            DOJrow = row[10]
            genderrow = row[5]
            arr1DOJfull.append(DOJrow)
            a += 1
            spliceDOJrowmale = DOJrow[7:8]
            arr2DOJyear.append(spliceDOJrowmale)
            print (DOJrow,genderrow)
