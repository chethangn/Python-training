# import csv
#
# import numpy as np

#with open("output_file.csv", 'r') as f:
#    data = list(csv.reader(f, delimiter=";"))
#    data = np.array(data[1:], dtype=np.float)
#print(data[:5])
#print data
# empty_array = np.zeros((10,10))
# print empty_array



import csv
import numpy as np
a=0
b=0
inf = csv.reader(open('output_file.csv','r'))
for row in inf:
  if row[5] == 'M' or row[5] == 'Male' or row[5] == 'M' or row[5] == 'male':
      a += 1
  if row[5] == 'F' or row[5] == 'Female' or row[5] == 'f' or row[5] == 'female':
      b += 1
print "No of male employees:"
print a
print "No of female employees:"
print b
