import csv
import numpy as np
import datetime as dtm
from datetime import timedelta
np.set_printoptions(threshold=np.inf)

timedata = np.array([])


#functions..
def num_there(s):
    return any(i.isdigit() for i in s)

# Opening a csv file..
with open('FormattedDataFeb.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    for row in inf:
        if num_there(row[0]):
            InHour = row[2][0:2]
            InMinutes = row[2][3:5]
            InSeconds = row[2][6:8]
            OutHour = row[3][0:2]
            OutMinutes = row[3][3:5]
            OutSeconds = row[3][6:8]
            Incovseconds = InHour*3600
            timedata = np.append(timedata,[[InHour,InMinutes,InSeconds,OutHour,OutMinutes,OutSeconds,Incovseconds]])
            timedata = timedata.reshape((timedata.shape[0], 1))
            timedata = timedata.reshape(-1, 7)
#             Insec = InHour * 3600 + InMinutes * 60 + InSeconds
#             Outsec = OutHour * 3600 + OutMinutes * 60 + OutSeconds
#             if count == 0:
#                 Insec = InHour * 3600 + InMinutes * 60 + InSeconds
#                 Outsec = OutHour * 3600 + OutMinutes * 60 + OutSeconds
#                 count = 1
#             if count == 1:
#                 Insec1 = InHour * 3600 + InMinutes * 60 + InSeconds
#                 Outsec1 = OutHour * 3600 + OutMinutes * 60 + OutSeconds
#                 avgtimein = Insec + Insec1
#                 avgtimeout = Outsec + Outsec1
#                 avgtimein = avgtimein/2
#                 avgtimeout = avgtimeout/2
# a = np.mean(timedata[:,0])
# Insec = 0
# print(timedata[:,0])
# for i in range(len(timedata)-1):
#     Insec = timedata[i,0] *3600
# print(Insec)
print(timedata)
