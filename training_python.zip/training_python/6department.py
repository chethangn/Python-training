import pandas as pd
import numpy as np
import csv
# Matrix = [[0 for x in range(w)] for y in range(h)]
information = pd.read_csv('output_file.csv', parse_dates=True)
inf = csv.reader(open('output_file.csv','r'))
# DOJ
# for row in inf:
#     DOJrow = row[10]
#     year = DOJrow[6:8]
#     DOJ = information[6:8]
#     print (DOJ)

#
# for content in inf
#     print ('none')

# for row in information:
#     print(row)

arr = information.groupby('DOJ')['DepartmentId'].mean().plot()

# arr = []
# DOJ_df = information['DOJ']
# DOJ = DOJ_df[2]
# year = DOJ
# year = year[6:9]
# print(year)
# i=0
# while i < 274:
#     DOJ_df = information['DOJ']
#     DOJ = DOJ_df[i]
#     year = DOJ
#     year = year[6:9]
#     information['DOJ'] = year
#     i += 1


# print (inf)
# for row in inf:
#     date = row[3]
#     print(date)
# DOJrow = inf['DOJ']
# zxc = DOJrow[1:4]
# print(zxc)
# print ('WELCOME to the database analysis\n')
# print ('Enter any of the following numbers')
# print ('1 -- Employee based department count')
# action = input ('Select an action :')
# print ('You have selected action',action,'to be performed')
# array = inf[['Designation','Remarks','DepartmentId']]

# print (array)
print (arr)
