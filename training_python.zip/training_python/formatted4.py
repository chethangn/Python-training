import csv
import numpy as np
import datetime as dtm
from datetime import timedelta
import time
np.set_printoptions(threshold=np.inf)

timedata = np.array([])
totalavg = 0

#functions..
def num_there(s):
    return any(i.isdigit() for i in s)

# Opening a csv file..
with open('FormattedDataFeb.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    for row in inf:
        if num_there(row[0]):
            InHour = int(row[2][0:2])
            InMinutes = int(row[2][3:5])
            InSeconds = int(row[2][6:8])
            OutHour = int(row[3][0:2])
            OutMinutes = int(row[3][3:5])
            OutSeconds = int(row[3][6:8])
            Incovseconds = InHour * 3600 + InMinutes * 60 + InSeconds
            Outcovseconds = OutHour * 3600 + OutMinutes * 60 + OutSeconds
            timedata = np.append(timedata,[[InHour,InMinutes,InSeconds,OutHour,OutMinutes,OutSeconds,Incovseconds,Outcovseconds]])
            timedata = timedata.reshape((timedata.shape[0], 1))
            timedata = timedata.reshape(-1, 8)

average_time_in_seconds = np.average(timedata[:,6])
average_time_in_format = time.strftime("%H:%M:%S", time.gmtime(average_time_in_seconds))
average_time_out_seconds = np.average(timedata[:,7])
average_time_out_format = time.strftime("%H:%M:%S", time.gmtime(average_time_out_seconds))
print("Average in time in feb",average_time_in_format)
print("Average out time in feb",average_time_out_format)
# print(timedata)
