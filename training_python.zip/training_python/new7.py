#         row[0] == Employee ID
#         row[1] == Employee Name
#         row[5] == Gender
#         row[8] == Designation
#         row[10] == DOJ


# Importing required libraries
import csv
import numpy as np


# import collections
import matplotlib.pyplot as plt
import json
import re


# Universal declarations to be used in function and outside
seen = []
name_column = 1
uniques = []


allEmployeeData = np.array([])
allEmployeeId = []
allDates = []
slice_content_days = np.array([])
deviceLogsContent = np.array([])
timingsLogs = np.array([])
formattedData = np.array([])
formattedData = np.append(formattedData,[['EmpID','EmpName','InTime','OutTime','Date']])
formattedData = formattedData.reshape((formattedData.shape[0], 1))
formattedData = formattedData.reshape(-1, 5)
year_male_count = []
count_2011 = 0
count = 0
month = []
year = []
year_val = []
month_val = []


# Function for checking out if name field contains number
def num_there(s):
    return any(i.isdigit() for i in s)


# Opening a csv file
with open('Employees_file.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    for row in inf:
        if row[name_column] not in seen and not (num_there(row[1])) and not row[5] == 'Gender':
            if row[5] == 'M' or row[5] == 'male':
                row[5] = 'Male'
            if row[5] == 'F' or row[5] == 'female':
                row[5] = 'Female'
            uniques.append(row)
            seen.append(row[name_column])
            row[10] = row[10][0:8]
            year_val = row[10][6:8]
            month_val = row[10][0:2]
            year.append(year_val)
            month.append(month_val)
            if re.match(r'^Del_', row[2]):
                row[2] = row[2][4:]
            allEmployeeData = np.append(allEmployeeData,[[row[2],row[1],row[5],row[10],row[8],month_val,year_val]])
            allEmployeeData = allEmployeeData.reshape((allEmployeeData.shape[0], 1))
            allEmployeeData = allEmployeeData.reshape(-1, 7)

            
with open('DeviceLogs1.csv') as csvfile:
    inf1 = csv.reader(csvfile, delimiter=',')
    for row in inf1:
        deviceLogsContent = np.append(deviceLogsContent,[[row[4],row[5]]])
        deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
        deviceLogsContent = deviceLogsContent.reshape(-1, 2)


# with open('DeviceLogs2.csv') as csvfile:
#     inf1 = csv.reader(csvfile, delimiter=',')
#     for row in inf1:
#         deviceLogsContent = np.append(deviceLogsContent,[[row[4],row[5]]])
#         deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
#         deviceLogsContent = deviceLogsContent.reshape(-1, 2)


# with open('DeviceLogs3.csv') as csvfile:
#     inf1 = csv.reader(csvfile, delimiter=',')
#     for row in inf1:
#         deviceLogsContent = np.append(deviceLogsContent,[[row[4],row[5]]])
#         deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
#         deviceLogsContent = deviceLogsContent.reshape(-1, 2)
# with open('DeviceLogs4.csv') as csvfile:
#     inf1 = csv.reader(csvfile, delimiter=',')
#     for row in inf1:
#         deviceLogsContent = np.append(deviceLogsContent,[[row[4],row[5]]])
#         deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
#         deviceLogsContent = deviceLogsContent.reshape(-1, 2)
# with open('DeviceLogs5.csv') as csvfile:
#     inf1 = csv.reader(csvfile, delimiter=',')
#     for row in inf1:
#         deviceLogsContent = np.append(deviceLogsContent,[[row[4],row[5]]])
#         deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
#         deviceLogsContent = deviceLogsContent.reshape(-1, 2)
# with open('DeviceLogs6.csv') as csvfile:
#     inf1 = csv.reader(csvfile, delimiter=',')
#     for row in inf1:
#         deviceLogsContent = np.append(deviceLogsContent,[[row[4],row[5]]])
#         deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
#         deviceLogsContent = deviceLogsContent.reshape(-1, 2)
# with open('DeviceLogs7.csv') as csvfile:
#     inf1 = csv.reader(csvfile, delimiter=',')
#     for row in inf1:
#         deviceLogsContent = np.append(deviceLogsContent,[[row[4],row[5]]])
#         deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
#         deviceLogsContent = deviceLogsContent.reshape(-1, 2)





i = 0

for i in range(len(deviceLogsContent)-1):
    allEmployeeId = np.unique(deviceLogsContent[:,0])
    Dates_value = np.unique(deviceLogsContent[i,1])
    Dates_value_spliced = Dates_value[0][:8]    
    allDates.append(Dates_value_spliced)
    i += 1
allDates = np.unique(allDates)






print(allEmployeeId,allDates)
# for i in range(len(Dates)-1):
#     allDates = Dates[0:8]

# j = 0
# i = 0
# for content in deviceLogsContent:
#     if i < 93:
#         allEmployeeId = np.unique(deviceLogsContent[:,0])
#         print(allEmployeeId[i])
#         i += 1        
# for content in deviceLogsContent:
#     print(
#     slice_content_day = slice_content_days[j]
#     slice_content_day = slice_content_day[0:2]
#     print(slice_content_day)
#     slice_content_days = np.unique(deviceLogsContent[:,1])
# #     print(slice_content_days[j])
#     j += 1
# for content in deviceLogsContent:
#     print(j)
#     slice_content = deviceLogsContent[j,1]
#     allDates = np.unique(slice_content[0:8])
#     print(allDates[j])
#     j += 1



# # for value in allEmployeeId:
# for content in deviceLogsContent:
#     deviceLogsContentID = deviceLogsContent[i,0]
#     slice_content = deviceLogsContent[i,1]

#     day = slice_content[3:5]
#     month = slice_content[0:2]
#     year = slice_content[6:8]
#     hours = slice_content[9:11]
#     minutes = slice_content[12:14]
#     seconds = slice_content[15:17]
    

# slice_content_days = deviceLogsContent[:,1]
# slice_content_days = slice_content_days[0:2]
# # allDates = np.unique(slice_content_days[0:8])
# print(slice_content_days)
