#         row[0] == Employee ID
#         row[1] == Employee Name
#         row[5] == Gender
#         row[8] == Designation
#         row[10] == DOJ



# Importing required libraries
import csv
import numpy as np

# import collections
import matplotlib.pyplot as plt
import json
import re

# Universal declarations to be used in function and outside
seen = []
name_column = 1
uniques = []

allEmployeeData = np.array([])
deviceLogsContent = np.array([])
timingsLogs = np.array([])
formattedData = np.array([])
formattedData = np.append(formattedData,[['EmpID','EmpName','InTime','OutTime','Date']])
formattedData = formattedData.reshape((formattedData.shape[0], 1))
formattedData = formattedData.reshape(-1, 5)
year_male_count = []
count_2011 = 0
count = 0
month = []
year = []
year_val = []
month_val = []
slice_content_days = []
# Function for checking out if name field contains number
def num_there(s):
    return any(i.isdigit() for i in s)


# Opening a csv file
with open('Employees_file.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    for row in inf:
        if row[name_column] not in seen and not (num_there(row[1])) and not row[5] == 'Gender':
            if row[5] == 'M' or row[5] == 'male':
                row[5] = 'Male'
            if row[5] == 'F' or row[5] == 'female':
                row[5] = 'Female'
            uniques.append(row)
            seen.append(row[name_column])
            row[10] = row[10][0:8]
            year_val = row[10][6:8]
            month_val = row[10][0:2]
            year.append(year_val)
            month.append(month_val)
            if re.match(r'^Del_', row[2]):
                row[2] = row[2][4:]      
                
            allEmployeeData = np.append(allEmployeeData,[[row[2],row[1],row[5],row[10],row[8],month_val,year_val]])
            allEmployeeData = allEmployeeData.reshape((allEmployeeData.shape[0], 1))
            allEmployeeData = allEmployeeData.reshape(-1, 7)

            
with open('DeviceLogs1.csv') as csvfile:
    inf1 = csv.reader(csvfile, delimiter=',')
    for row in inf1:
        date = row[5][3:5]
        month = row[5][0:2]
        deviceLogsContent = np.append(deviceLogsContent,[[row[4],row[5]]])
        deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
        deviceLogsContent = deviceLogsContent.reshape(-1, 2)
# with open('DeviceLogs2.csv') as csvfile:
#     inf1 = csv.reader(csvfile, delimiter=',')
#     for row in inf1:
#         c = np.append(c,[[row[4],row[5]]])
#         c = c.reshape((c.shape[0], 1))
#         c = c.reshape(-1, 2)
# with open('DeviceLogs3.csv') as csvfile:
#     inf1 = csv.reader(csvfile, delimiter=',')
#     for row in inf1:
#         c = np.append(c,[[row[4],row[5]]])
#         c = c.reshape((c.shape[0], 1))
#         c = c.reshape(-1, 2)
# with open('DeviceLogs4.csv') as csvfile:
#     inf1 = csv.reader(csvfile, delimiter=',')
#     for row in inf1:
#         c = np.append(c,[[row[4],row[5]]])
#         c = c.reshape((c.shape[0], 1))
#         c = c.reshape(-1, 2)
# with open('DeviceLogs5.csv') as csvfile:
#     inf1 = csv.reader(csvfile, delimiter=',')
#     for row in inf1:
#         c = np.append(c,[[row[4],row[5]]])
#         c = c.reshape((c.shape[0], 1))
#         c = c.reshape(-1, 2)
# with open('DeviceLogs6.csv') as csvfile:
#     inf1 = csv.reader(csvfile, delimiter=',')
#     for row in inf1:
#         c = np.append(c,[[row[4],row[5]]])
#         c = c.reshape((c.shape[0], 1))
#         c = c.reshape(-1, 2)
# with open('DeviceLogs7.csv') as csvfile:
#     inf1 = csv.reader(csvfile, delimiter=',')
#     for row in inf1:
#         c = np.append(c,[[row[4],row[5]]])
#         c = c.reshape((c.shape[0], 1))
#         c = c.reshape(-1, 2)



# i = 0
# for id in c:
#     print(c[i])
#     i += 1



j = 0
i = 1
# for value in allEmployeeId:
for content in deviceLogsContent:
    deviceLogsContentID = deviceLogsContent[i,0]
    slice_content = deviceLogsContent[i,1]
    slice_content_days = slice_content[0:8]
    day = slice_content[3:5]
    month = slice_content[0:2]
    year = slice_content[6:8]
    hours = slice_content[9:11]
    minutes = slice_content[12:14]
    seconds = slice_content[15:17]
    allDates = np.unique(slice_content_days)

print(allDates)
#     if allEmployeeId[j] == deviceLogsContentID:
#         print(day,month,year)
#     i += 1
#     j += 1


#         if year[i] == year[i+1] and month[i] == month[i+1] and day[i] == day[i+1]:

#             print(max(hours))
#             print("Hello")





#             if hours[i] < hours[i+1]:
#                 intime = slice_content[9:17]
#                 if minutes[i] <= minutes[i+1]:
#                     if seconds[i] <= seconds[i+1]:

# print(deviceLogsContent[:,1])
#     i += 1
#     for row in deviceLogsContent:
#         comparable = deviceLogsContent[i,j]
#         if firstContentRow == comparable:
#             b = np.append(b,[[deviceLogsContent[i]]])
#             b = b.reshape((b.shape[0], 1))
#             b = b.reshape(-1, 1)
#     print(day,month,year,hours,minutes,seconds,slice_content)

# print(deviceLogsContent[:,1])

# print(c[0])





# myFile = open('example2.csv', 'w')
# with myFile:
#     writer = csv.writer(myFile)
#     writer.writerows(a)
     




# c[i,0]


male_total = int(np.sum(allEmployeeData[:,2] == 'Male'))
female_total = int(np.sum(allEmployeeData[:,2] == 'Female'))
print(type(male_total))

year_2011 = np.sum(allEmployeeData[:,6] == '11')
year_2012 = np.sum(allEmployeeData[:,6] == '12')
year_2013 = np.sum(allEmployeeData[:,6] == '13')
year_2014 = np.sum(allEmployeeData[:,6] == '14')
year_2015 = np.sum(allEmployeeData[:,6] == '15')
year_2016 = np.sum(allEmployeeData[:,6] == '16')
year_2017 = np.sum(allEmployeeData[:,6] == '17')



year_2011_male = allEmployeeData[:,1][np.logical_and(allEmployeeData[:,6] == '11', allEmployeeData[:,2] == 'Male')].size
year_2012_male = allEmployeeData[:,1][np.logical_and(allEmployeeData[:,6] == '12', allEmployeeData[:,2] == 'Male')].size
year_2013_male = allEmployeeData[:,1][np.logical_and(allEmployeeData[:,6] == '13', allEmployeeData[:,2] == 'Male')].size
year_2014_male = allEmployeeData[:,1][np.logical_and(allEmployeeData[:,6] == '14', allEmployeeData[:,2] == 'Male')].size
year_2015_male = allEmployeeData[:,1][np.logical_and(allEmployeeData[:,6] == '15', allEmployeeData[:,2] == 'Male')].size
year_2016_male = allEmployeeData[:,1][np.logical_and(allEmployeeData[:,6] == '16', allEmployeeData[:,2] == 'Male')].size
year_2017_male = allEmployeeData[:,1][np.logical_and(allEmployeeData[:,6] == '17', allEmployeeData[:,2] == 'Male')].size


year_2011_female = allEmployeeData[:,1][np.logical_and(allEmployeeData[:,6] == '11', allEmployeeData[:,2] == 'Female')].size
year_2012_female = allEmployeeData[:,1][np.logical_and(allEmployeeData[:,6] == '12', allEmployeeData[:,2] == 'Female')].size
year_2013_female = allEmployeeData[:,1][np.logical_and(allEmployeeData[:,6] == '13', allEmployeeData[:,2] == 'Female')].size
year_2014_female = allEmployeeData[:,1][np.logical_and(allEmployeeData[:,6] == '14', allEmployeeData[:,2] == 'Female')].size
year_2015_female = allEmployeeData[:,1][np.logical_and(allEmployeeData[:,6] == '15', allEmployeeData[:,2] == 'Female')].size
year_2016_female = allEmployeeData[:,1][np.logical_and(allEmployeeData[:,6] == '16', allEmployeeData[:,2] == 'Female')].size
year_2017_female = allEmployeeData[:,1][np.logical_and(allEmployeeData[:,6] == '17', allEmployeeData[:,2] == 'Female')].size



print("total male employee count is",male_total)
print("total female employee count is",female_total)
total_emp = male_total + female_total
print("total number of employees are",total_emp)



year_2011 = year_2011+1
print("----------------------------------------------------------------------------------------")
print("Total employee hired in 2011",year_2011)
print("Total employee hired in 2012",year_2012)
print("Total employee hired in 2013",year_2013)
print("Total employee hired in 2014",year_2014)
print("Total employee hired in 2015",year_2015)
print("Total employee hired in 2016",year_2016)
print("Total employee hired in 2017",year_2017)
print("----------------------------------------------------------------------------------------")
print("Total count per year basis")

print("Total employee in 2011",year_2011)
print("Total employee in 2012",year_2011+year_2012)
print("Total employee in 2013",year_2011+year_2012+year_2013)
print("Total employee in 2014",year_2011+year_2012+year_2013+year_2014)
print("Total employee in 2015",year_2011+year_2012+year_2013+year_2014+year_2015)
print("Total employee in 2016",year_2011+year_2012+year_2013+year_2014+year_2015+year_2016)
print("Total employee in 2017",year_2011+year_2012+year_2013+year_2014+year_2015+year_2016+year_2017)

print("-------------------------------------------------------------------------------------------")
print("Yearly based hired male count 2011", year_2011_male," Female count 2011",year_2011_female)
print("Yearly based hired male count 2012", year_2012_male," Female count 2012",year_2012_female)
print("Yearly based hired male count 2013", year_2013_male," Female count 2013",year_2013_female)
print("Yearly based hired male count 2014", year_2014_male," Female count 2014",year_2014_female)
print("Yearly based hired male count 2015", year_2015_male,"Female count 2015",year_2015_female)
print("Yearly based hired male count 2016", year_2016_male,"Female count 2016",year_2016_female)
print("Yearly based hired male count 2017", year_2017_male,"Female count 2017",year_2017_female)



# total_count = [male_total,female_total,total_emp]
# total_count = np.array(total_count).tolist()
# yearly_count = [year_2011,year_2012,year_2013,year_2014,year_2015,year_2016,year_2017]
# yearly_count = np.array(yearly_count).tolist()
# yearly_male_count = [year_2011_male,year_2012_male,year_2013_male,year_2014_male,year_2015_male,year_2016_male,year_2017_male]
# yearly_male_count = np.array(yearly_male_count).tolist()
# year_female_count = [year_2011_female,year_2012_female,year_2013_female,year_2014_female,year_2015_female,year_2016_female,year_2017_female]
# year_female_count = np.array(year_female_count).tolist()
# with open('data.txt', 'w') as outfile:  
#     json.dump(total_count, outfile)
#     json.dump(yearly_count, outfile)
#     json.dump(yearly_male_count, outfile)
#     json.dump(year_female_count, outfile)

