# Here    row[0] == Employee ID
#         row[1] == Employee Name
#         row[5] == Gender
#         row[8] == Designation
#         row[10] == DOJ




# Importing required libraries
import csv
import numpy as np





# Universal declarations to be used in function and outside
seen = []
name_column = 1
uniques = []
# a = np.empty([300, 5])
a = np.array([])
# a= np.empty(shape=[0, n])

# Function for checking out if name field contains number
def num_there(s):
    return any(i.isdigit() for i in s)


# Opening a csv file
with open('Employees_file.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    for row in inf:
        if row[name_column] not in seen and not (num_there(row[1])) and not row[5] == 'Gender':
            if row[5] == 'M' or row[5] == 'male':
                row[5] = 'Male'
            if row[5] == 'F' or row[5] == 'female':
                row[5] = 'Female'
            uniques.append(row)
            seen.append(row[name_column])
            row[10] = row[10][0:8]
#             employeeId = row[0]
#             employeeName = row[1]
#             gender = row[5]
#             designation = row[8]
#             DOJ = row[10]
#             l = [employeeId,employeeName,gender,DOJ,designation]
            a = np.append(a,[[row[0],row[1],row[5],row[10],row[8]]])
#             a = np.vstack([a,l])
            a = a.reshape((a.shape[0], 1))
#             b = np.reshape(a,(-1,ncols))
            a = a.reshape(-1, 5)
print (a[:,1])
