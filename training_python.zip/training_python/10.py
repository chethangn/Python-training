import csv
import numpy as np
a = []
b = []
i = 0
j = 0
inf = csv.reader(open('output_file.csv', 'r'))
for col in inf:
    emp_name = col[1]
    emp_sex = col[5]
    database = [emp_name, emp_sex]
    # print(database)
    # a = np.array([col[1], col[5]])
    b = b.append([col[1]])
# print(database[0][0][0])
# print(arr)
# r = np.genfromtxt('test.csv', delimiter=',', dtype=None, names=True)
# print(r)
print(b)
