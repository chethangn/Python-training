import csv
import numpy as np
import datetime as dtm
from datetime import timedelta
import time
np.set_printoptions(threshold=np.inf)

timedata = np.array([])
totalavg = 0

#functions..
def num_there(s):
    return any(i.isdigit() for i in s)

# Opening a npy file..
data = np.array([])

data = np.load('formattedFeb.npy')
i = -1
for row in range(len(data)):
    i += 1
    if num_there(data[i,0]):
        intime = data[i,2]
        outtime = data[i,3]
        InHour = float(intime[0:2])
        InMinutes = float(intime[3:5])
        InSeconds = float(intime[6:8])
        OutHour = float(outtime[0:2])
        OutMinutes = float(outtime[3:5])
        OutSeconds = float(outtime[6:8])
        Incovseconds = InHour * 3600 + InMinutes * 60 + InSeconds
        Outcovseconds = OutHour * 3600 + OutMinutes * 60 + OutSeconds
        timedata = np.append(timedata,[[InHour,InMinutes,InSeconds,OutHour,OutMinutes,OutSeconds,Incovseconds,Outcovseconds]])
        timedata = timedata.reshape((timedata.shape[0], 1))
        timedata = timedata.reshape(-1, 8)
average_time_in_seconds = np.average(timedata[:,6])
average_time_in_format = time.strftime("%H:%M:%S", time.gmtime(average_time_in_seconds))
average_time_out_seconds = np.average(timedata[:,7])
average_time_out_format = time.strftime("%H:%M:%S", time.gmtime(average_time_out_seconds))
print("Average in time in feb",average_time_in_format)
print("Average out time in feb",average_time_out_format)
