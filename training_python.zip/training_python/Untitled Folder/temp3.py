import csv
import numpy as np
import datetime as dtm
from datetime import timedelta
import time
np.set_printoptions(threshold=np.inf)

timedata = np.array([])
totalavg = 0

#functions..
def num_there(s):
    return any(i.isdigit() for i in s)

# Opening a npy file..
data = np.array([])

data = np.load('formattedFeb.npy')
# i = -1
# for row in range(len(data)):
#     i += 1
#     if num_there(data[i,0]):
#         intime = data[i,2]
#         outtime = data[i,3]
#         InHour = int(intime[0:2])
#         InMinutes = int(intime[3:5])
#         InSeconds = int(intime[6:8])
#         OutHour = int(outtime[0:2])
#         OutMinutes = int(outtime[3:5])
#         OutSeconds = int(outtime[6:8])
#         Incovseconds = InHour * 3600 + InMinutes * 60 + InSeconds
#         Outcovseconds = OutHour * 3600 + OutMinutes * 60 + OutSeconds
#         timedata = np.append(timedata,[[InHour,InMinutes,InSeconds,OutHour,OutMinutes,OutSeconds,Incovseconds,Outcovseconds]])
#         timedata = timedata.reshape((timedata.shape[0], 1))
#         timedata = timedata.reshape(-1, 8)


# This is the problem......
print(data[:,2][1:3])

# I cannot use it here....
time_list = map(lambda s: int(s[6:8]) + 60*(int(s[3:5]) + 60*int(s[0:2])), data[:,2])
average = sum(time_list)/len(time_list)
bigmins, secs = divmod(average, 60)
hours, mins = divmod(bigmins, 60)
# print(hours, mins, secs)





# average_time_in_seconds = np.average(timedata[:,6])
# average_time_in_format_feb = time.strftime("%H:%M:%S", time.gmtime(average_time_in_seconds))
# average_time_out_seconds = np.average(timedata[:,7])
# average_time_out_format_feb = time.strftime("%H:%M:%S", time.gmtime(average_time_out_seconds))
# print("Average in time in feb",average_time_in_format_feb)
# print("Average out time in feb",average_time_out_format_feb)
