import csv
import numpy as np
import re
r = re.compile('^\d{2}/\d{2}/\d{2} T\d{2}:\d{2}:\d{2}\+\d{2}')
a=0
b=0
with open('output_file.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    for row in inf:
        if row[5] == 'M' or row[5] == 'Male' or row[5] == 'M' or row[5] == 'male' and r.match(row[10]):
            row=row[10]
            a += 1
        if row[5] == 'F' or row[5] == 'Female' or row[5] == 'f' or row[5] == 'female' and r.match(row[10]):
            b += 1

with open('output_file.csv') as csvfile:
    readCSV = csv.reader(csvfile, delimiter=',')
    arr = []
    for row in readCSV:
        DOJ = row[10]
        arr.append(DOJ)
        print DOJ
        print "\n"
    print(arr)

print "No of male employees:"
print a
print "No of female employees:"
print b
