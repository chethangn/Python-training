# Author : Chethan Kumar G N
# Date   : 14/11/17
# Email  : chethan1gn@gmail.com



from __future__ import print_function

import csv
import numpy as np
import re
a = []
b = []
male_count_yearly_basis = []
female_count_yearly_basis = []
male_count_monthly_basis = []
female_count_monthly_basis = []
total_employee_count = 0
male_employee_count = 0
female_employee_count = 0
seen = set()
start_year=2011
current_year = 2017
number_of_years = current_year - start_year + 1
male_array_per_year_count = [0] * number_of_years
female_array_per_year_count = [0] * number_of_years
male_array_per_month_count = [0] * 12
female_array_per_month_count = [0] * 12
inf = csv.reader(open('output_file.csv','r'))
print('WELCOME to the database analysis\n')
print('Enter any of the following numbers')
print('1 -- Total emplyee hired')
print('2 -- Total male and female employee hired count')
print('3 -- Male and Female count based on yearly basis')
print('4 -- Male and Female count based on monthly basis')
print('5 -- needed 5')
action = input('Select an action :')
print('You have selected action',action,'to be performed')

# Employee count monthly basis
def emp_count_monthly_basis():
    male_employee_count_function_month_value = 0
    female_employee_count_function_month_value = 0
    # Row access in inf
    for row in inf:
        if row[5] == 'M' or row[5] == 'Male' or row[5] == 'm' or row[5] == 'male':
            DOJrow = row[10]
            year = DOJrow[6:8]
            month = DOJrow[0:2]
            name = row[1]
            name_not_number = name.isdigit()
            if name not in seen:
                if year != '00' and year != '0' and name_not_number != True:
                    if month == '01':
                        male_array_per_month_count[0] += 1
                        male_count_monthly_basis = np.array([row[5], year,name,male_array_per_month_count[0]])
                        male_employee_count_function_month_value += 1
                    if month == '02':
                        male_array_per_month_count[1] += 1
                        male_count_monthly_basis = np.array([row[5], year,name,male_array_per_month_count[1]])
                        male_employee_count_function_month_value += 1
                    if month == '03':
                        male_array_per_month_count[2] += 1
                        male_count_monthly_basis = np.array([row[5], year,name,male_array_per_month_count[2]])
                        male_employee_count_function_month_value += 1
                    if month == '04':
                        male_array_per_month_count[3] += 1
                        male_count_monthly_basis = np.array([row[5], year,name,male_array_per_month_count[3]])
                        male_employee_count_function_month_value += 1
                    if month == '05':
                        male_array_per_month_count[4] += 1
                        male_count_monthly_basis = np.array([row[5], year,name,male_array_per_month_count[4]])
                        male_employee_count_function_month_value += 1
                    if month == '06':
                        male_array_per_month_count[5] += 1
                        male_count_monthly_basis = np.array([row[5], year,name,male_array_per_month_count[5]])
                        male_employee_count_function_month_value += 1
                    if month == '07':
                        male_array_per_month_count[6] += 1
                        male_count_monthly_basis = np.array([row[5], year,name,male_array_per_month_count[6]])
                        male_employee_count_function_month_value += 1
                    if month == '08':
                        male_array_per_month_count[7] += 1
                        male_count_monthly_basis = np.array([row[5], year,name,male_array_per_month_count[7]])
                        male_employee_count_function_month_value += 1
                    if month == '09':
                        male_array_per_month_count[8] += 1
                        male_count_monthly_basis = np.array([row[5], year,name,male_array_per_month_count[8]])
                        male_employee_count_function_month_value += 1
                    if month == '10':
                        male_array_per_month_count[9] += 1
                        male_count_monthly_basis = np.array([row[5], year,name,male_array_per_month_count[9]])
                        male_employee_count_function_month_value += 1
                    if month == '11':
                        male_array_per_month_count[10] += 1
                        male_count_monthly_basis = np.array([row[5], year,name,male_array_per_month_count[10]])
                        male_employee_count_function_month_value += 1
                    if month == '12':
                        male_array_per_month_count[11] += 1
                        male_count_monthly_basis = np.array([row[5], year,name,male_array_per_month_count[11]])
                        male_employee_count_function_month_value += 1


        if row[5] == 'F' or row[5] == 'Female' or row[5] == 'f' or row[5] == 'female':
            DOJrow = row[10]
            year = DOJrow[6:8]
            month = DOJrow[0:2]
            name = row[1]
            name_not_number = name.isdigit()
            if name not in seen:
                if year != '00' and year != '0' and name_not_number != True:
                        if month == '01':
                            female_array_per_month_count[0] += 1
                            female_count_monthly_basis = np.array([row[5], year,name,female_array_per_month_count[0]])
                            female_employee_count_function_month_value += 1
                        if month == '02':
                            female_array_per_month_count[1] += 1
                            female_count_monthly_basis = np.array([row[5], year,name,female_array_per_month_count[1]])
                            female_employee_count_function_month_value += 1
                        if month == '03':
                            female_array_per_month_count[2] += 1
                            female_count_monthly_basis = np.array([row[5], year,name,female_array_per_month_count[2]])
                            female_employee_count_function_month_value += 1
                        if month == '04':
                            female_array_per_month_count[3] += 1
                            female_count_monthly_basis = np.array([row[5], year,name,female_array_per_month_count[3]])
                            female_employee_count_function_month_value += 1
                        if month == '05':
                            female_array_per_month_count[4] += 1
                            female_count_monthly_basis = np.array([row[5], year,name,female_array_per_month_count[4]])
                            female_employee_count_function_month_value += 1
                        if month == '06':
                            female_array_per_month_count[5] += 1
                            female_count_monthly_basis = np.array([row[5], year,name,female_array_per_month_count[5]])
                            female_employee_count_function_month_value += 1
                        if month == '07':
                            female_array_per_month_count[6] += 1
                            female_count_monthly_basis = np.array([row[5], year,name,female_array_per_month_count[6]])
                            female_employee_count_function_month_value += 1
                        if month == '08':
                            female_array_per_month_count[7] += 1
                            female_count_monthly_basis = np.array([row[5], year,name,female_array_per_month_count[7]])
                            female_employee_count_function_month_value += 1
                        if month == '09':
                            female_array_per_month_count[8] += 1
                            female_count_monthly_basis = np.array([row[5], year,name,female_array_per_month_count[8]])
                            female_employee_count_function_month_value += 1
                        if month == '10':
                            female_array_per_month_count[9] += 1
                            female_count_monthly_basis = np.array([row[5], year,name,female_array_per_month_count[9]])
                            female_employee_count_function_month_value += 1
                        if month == '11':
                            female_array_per_month_count[10] += 1
                            female_count_monthly_basis = np.array([row[5], year,name,female_array_per_month_count[10]])
                            female_employee_count_function_month_value += 1
                        if month == '12':
                            female_array_per_month_count[11] += 1
                            female_count_monthly_basis = np.array([row[5], year,name,female_array_per_month_count[11]])
                            female_employee_count_function_month_value += 1
    return male_employee_count_function_month_value,female_count_monthly_basis;





# Employee count both male and female
def emp_count():
    male_employee_count_function_value = 0
    female_employee_count_function_value = 0
    for row in inf:
        if row[5] == 'M' or row[5] == 'Male' or row[5] == 'm' or row[5] == 'male':
            DOJrow = row[10]
            year = DOJrow[6:8]
            name = row[1]
            name_not_number = name.isdigit()
            if name not in seen:
                if year != '00' and year != '0' and name_not_number != True:
                    b = np.array([row[5], year,name])
                    male_employee_count_function_value += 1
        if row[5] == 'F' or row[5] == 'Female' or row[5] == 'f' or row[5] == 'female':
            DOJrow = row[10]
            year = DOJrow[6:8]
            name = row[1]
            name_not_number = name.isdigit()
            if name not in seen:
                if year != '00' and year != '0' and name_not_number != True:
                    a = np.array([row[5], year,name])
                    female_employee_count_function_value += 1
    return male_employee_count_function_value,female_employee_count_function_value;



# Employee based on count yearly basis

def emp_count_yearly_basis():
    male_employee_count_function_value = 0
    female_employee_count_function_value = 0
    for row in inf:
        if row[5] == 'M' or row[5] == 'Male' or row[5] == 'm' or row[5] == 'male':
            DOJrow = row[10]
            year = DOJrow[6:8]
            name = row[1]
            name_not_number = name.isdigit()
            if name not in seen:
                if year != '00' and year != '0' and name_not_number != True:
                    if year == '11':
                        male_array_per_year_count[0] += 1
                        b = np.array([row[5], year,name,male_array_per_year_count[0]])
                        male_employee_count_function_value += 1
                    if year == '12':
                        male_array_per_year_count[1] += 1
                        b = np.array([row[5], year,name,male_array_per_year_count[1]])
                        male_employee_count_function_value += 1
                    if year == '13':
                        male_array_per_year_count[2] += 1
                        b = np.array([row[5], year,name,male_array_per_year_count[2]])
                        male_employee_count_function_value += 1
                    if year == '14':
                        male_array_per_year_count[3] += 1
                        b = np.array([row[5], year,name,male_array_per_year_count[3]])
                        male_employee_count_function_value += 1
                    if year == '15':
                        male_array_per_year_count[4] += 1
                        b = np.array([row[5], year,name,male_array_per_year_count[4]])
                        male_employee_count_function_value += 1
                    if year == '16':
                        male_array_per_year_count[5] += 1
                        b = np.array([row[5], year,name,male_array_per_year_count[5]])
                        male_employee_count_function_value += 1
                    if year == '17':
                        male_array_per_year_count[6] += 1
                        b = np.array([row[5], year,name,male_array_per_year_count[6]])
                        male_employee_count_function_value += 1
        if row[5] == 'F' or row[5] == 'Female' or row[5] == 'f' or row[5] == 'female':
            DOJrow = row[10]
            year = DOJrow[6:8]
            name = row[1]
            name_not_number = name.isdigit()
            if name not in seen:
                if year != '00' and year != '0' and name_not_number != True:
                    if year == '11':
                        female_array_per_year_count[0] += 1
                        a = np.array([row[5], year,name])
                        female_employee_count_function_value += 1
                    if year == '12':
                        female_array_per_year_count[1] += 1
                        a = np.array([row[5], year,name])
                        female_employee_count_function_value += 1
                    if year == '13':
                        female_array_per_year_count[2] += 1
                        a = np.array([row[5], year,name])
                        female_employee_count_function_value += 1
                    if year == '14':
                        female_array_per_year_count[3] += 1
                        a = np.array([row[5], year,name])
                        female_employee_count_function_value += 1
                    if year == '15':
                        female_array_per_year_count[4] += 1
                        a = np.array([row[5], year,name])
                        female_employee_count_function_value += 1
                    if year == '16':
                        female_array_per_year_count[5] += 1
                        a = np.array([row[5], year,name])
                        female_employee_count_function_value += 1
                    if year == '17':
                        female_array_per_year_count[6] += 1
                        a = np.array([row[5], year,name])
                        female_employee_count_function_value += 1
    return male_employee_count_function_value,female_employee_count_function_value;



if action == 1:
    print("hello2")
    male_employee_count,female_employee_count=emp_count()
    total_employee_count = male_employee_count + female_employee_count
    print ("Total employees hired till date is:",total_employee_count)





elif action == 2:
    male_employee_count,female_employee_count=emp_count()
    print ('Total male employees is',male_employee_count)
    print ('Total female employess is',female_employee_count)


elif action == 3:
    male_employee_count,female_employee_count=emp_count_yearly_basis()
    print('Male count every year is as follows')
    year = start_year
    total_years_male = number_of_years
    count_male = 0
    while total_years_male > 0 :
        # print(male_array_per_year_count[count_male],year)
        male_count_yearly_basis = np.array([male_array_per_year_count[count_male],year])
        count_male += 1
        total_years_male -= 1
        year += 1
        print(male_count_yearly_basis)
    print('Female count every year is as follows')
    year = start_year
    total_years_female = number_of_years
    count_female = 0
    while total_years_female > 0 :
        female_count_yearly_basis = np.array([female_array_per_year_count[count_female],year])
        count_female += 1
        total_years_female -= 1
        year += 1
        print(female_count_yearly_basis)





elif action == 4:
    print ('Male count on monthly basis is as follows')
    emp_count_monthly_basis()
    count = 0
    month = 1
    total_months_male = 12

    while total_months_male > 0:
        # print(male_array_per_year_count[count_male],year)
        male_count_monthly_basis = np.array([male_array_per_month_count[count],month])
        count += 1
        total_months_male -= 1
        month += 1
        print (male_count_monthly_basis)
    print ('Female count on monthly basis is as follows')
    count = 0
    month = 1
    total_months_female = 12
    while total_months_female > 0:
        female_count_monthly_basis = np.array([female_array_per_month_count[count],month])
        count += 1
        total_months_female -= 1
        month += 1
        print (female_count_monthly_basis)
elif action == 5:
    print('Action 5')