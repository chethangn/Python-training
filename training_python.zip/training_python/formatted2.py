import csv
import numpy as np
import datetime as dtm
from datetime import timedelta
np.set_printoptions(threshold=np.inf)

avgtimein = 0
avgtimeout = 0

# Functions
# def avg_time(times):
#     avg = 0
#     for elem in times:
#         avg += elem.second + 60*elem.minute + 3600*elem.hour
#     avg /= len(times)
#     rez = str(avg/3600) + ' ' + str((avg%3600)/60) + ' ' + str(avg%60)
#     return dtm.datetime.strptime(rez, "%H %M %S")

#def avg_time(InHour,InMinutes,InSeconds,OutHour,OutMinutes,OutSeconds):
#    Insec = InHour * 3600 + InMinutes * 60 + InSeconds
#    Outsec = OutHour * 3600 + OutMinutes * 60 + OutSeconds
#    avgtimein = (Insec + avgtimein)/2
#    avgtimeout = (Outsec + avgtimeout)/2
    
def num_there(s):
    return any(i.isdigit() for i in s)
Insec = 0
Outsec = 0
# Opening a csv file
with open('FormattedDataFeb.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    for row in inf:
        if num_there(row[0]):
            InHour = row[2][0:2]
            InMinutes = row[2][3:5]
            InSeconds = row[2][6:8]
            OutHour = row[3][0:2]
            OutMinutes = row[3][3:5]
            OutSeconds = row[3][6:8]
	    Insec=InHour
    	    Outsec = OutHour*3600+OutMinutes*60+OutSeconds
	    print(Insec,Outsec)
