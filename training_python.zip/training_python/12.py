import csv
with open('output_file.csv', 'rb') as csvfile:
    inf = csv.reader(csvfile, delimiter=' ', quotechar='|')
    for row in inf:
        print (', '.join(row))
