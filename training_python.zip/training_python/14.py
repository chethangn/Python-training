# Here    row[0] == Employee ID
#         row[1] == Employee Name
#         row[5] == Gender
#         row[8] == Designation
#         row[10] == DOJ




# Importing required libraries
import csv
import numpy as np
a = np.empty()




# Universal declarations to be used in function and outside
seen = []
name_column = 1
uniques = []




# Function for checking out if name field contains number
def num_there(s):
    return any(i.isdigit() for i in s)




# Opening a csv file
with open('Employees_file.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    for row in inf:
        if row[name_column] not in seen and not (num_there(row[1])):
            if row[5] == 'M' or row[5] == 'male':
                row[5] = 'Male'
            if row[5] == 'F' or row[5] == 'female':
                row[5] = 'Female'
            uniques.append(row)
            seen.append(row[name_column])
            row[10] = row[10][0:8]
#             print(row[0],row[1],row[5],row[10],row[8])





# Conversion of this into numpy
            a = np.array([[row[0],row[1],row[5],row[10],row[8]]])
	    a = np.append(a, [[row[0],row[1],row[5],row[10],row[8]]])
    
    
#  prints all data in numpy
            print (a)
    
    
#  prints shape of numpy array
            print(a.shape)
    
    
    
#             a = np.delete(a, (0), axis=0)
#             a = np.delete(a, 0, 1)
#             print(a[:,1])
#             a = np.delete(a, 1, 1)
#             a = np.delete(a, (0), axis=0)



#             a = np.arange(3.0)




#             print(a)
#             np.concatenate((inf[:0], [66], inf[0:]))
# with open("test.csv",'r') as f, open("updated_test.csv",'w') as f1:
#     next(f) # skip header line
#     for line in f:
#         f1.write(line)
        
        
        

            

# with open('yourfile.csv', 'r') as f:
#     reader = csv.reader(f, delimiter='\t')
#     for row in reader:
#        if row[dup_scan_col] not in seen:
#           uniques.append(row)
#           seen.append(row[dup_scan_col])
