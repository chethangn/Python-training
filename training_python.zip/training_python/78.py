# Here    row[0] == Employee ID
#         row[1] == Employee Name
#         row[5] == Gender
#         row[8] == Designation
#         row[10] == DOJ


# Importing required libraries
import csv
import numpy as np
import fnmatch


# Universal declarations to be used in function and outside
seen = []
name_column = 1
uniques = []
a = np.array([])


# Function for checking out if name field contains number
def num_there(s):
    return any(i.isdigit() for i in s)
action = 0


# Opening a csv file and formatting it
with open('Employees_file.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    for row in inf:
        if row[name_column] not in seen and not (num_there(row[1])) and not row[5] == 'Gender':
            if row[5] == 'M' or row[5] == 'male':
                row[5] = 'Male'
            if row[5] == 'F' or row[5] == 'female':
                row[5] = 'Female'
            uniques.append(row)
            seen.append(row[name_column])
            row[10] = row[10][0:8]
            a = np.append(a,[[row[0],row[1],row[5],row[10],row[8]]])
            a = a.reshape((a.shape[0], 1))
            a = a.reshape(-1, 5)    


def emp_count():
    male_employee_count = 0
    female_employee_count = 0
    for item in a[:,2]:
        if fnmatch.fnmatch(item, "Male"):
            male_employee_count += 1
        elif fnmatch.fnmatch(item, "Female"):
            female_employee_count += 1
    return male_employee_count,female_employee_count;


print ('WELCOME to the database analysis\n')
print ('Enter any of the following numbers')
print ('1 -- Total emplyee hired')
print ('2 -- Total male and female employee hired count')
print ('3 -- Male and Female count based on yearly basis')
print ('4 -- Male and Female count based on monthly basis')
action = input('Select an action: ')
print ('You have selected action',action,'to be performed')
if action == '1':
    male_employee_count,female_employee_count = emp_count()
    total_employee_count = male_employee_count + female_employee_count
    print ("Total employees hired till date is:",total_employee_count)

# elif action == 2:
#     male_employee_count,female_employee_count = emp_count()
#     print ("Total male employee count",male_employee_count)    

