#         row[0] == Employee ID
#         row[1] == Employee Name
#         row[5] == Gender
#         row[8] == Designation
#         row[10] == DOJ


# Importing required libraries
import csv
import numpy as np


# import collections
import matplotlib.pyplot as plt
import json
import re


# Universal declarations to be used in function and outside
seen = []
name_column = 1
uniques = []


allEmployeeData = np.array([])
allEmployeeId = []
allDates = []
slice_content_days = np.array([])
deviceLogsContent = np.array([])
timingsLogs = np.array([])
formattedData = np.array([])
formattedData = np.append(formattedData,[['EmpID','EmpName','InTime','OutTime','Date']])
formattedData = formattedData.reshape((formattedData.shape[0], 1))
formattedData = formattedData.reshape(-1, 5)
year_male_count = []
count_2011 = 0
count = 0
month = []
year = []
year_val = []
month_val = []

# Function for checking out if name field contains number
def num_there(s):
    return any(i.isdigit() for i in s)


# Opening a csv file
with open('Employees_file.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    for row in inf:
        if row[name_column] not in seen and not (num_there(row[1])) and not row[5] == 'Gender':
            if row[5] == 'M' or row[5] == 'male':
                row[5] = 'Male'
            if row[5] == 'F' or row[5] == 'female':
                row[5] = 'Female'
            uniques.append(row)
            seen.append(row[name_column])
            row[10] = row[10][0:8]
            year_val = row[10][6:8]
            month_val = row[10][0:2]
            year.append(year_val)
            month.append(month_val)
            if re.match(r'^Del_', row[2]):
                row[2] = row[2][4:]
            allEmployeeData = np.append(allEmployeeData,[[row[2],row[1],row[5],row[10],row[8],month_val,year_val]])
            allEmployeeData = allEmployeeData.reshape((allEmployeeData.shape[0], 1))
            allEmployeeData = allEmployeeData.reshape(-1, 7)
# print(allEmployeeData)

with open('DeviceLogs1.csv') as csvfile:
    inf1 = csv.reader(csvfile, delimiter=',')
    next(inf1)
    for row in inf1:
        datesSplicedValue = row[5][:8]
        timeSplicedValue = row[5][9:17]
        deviceLogsContent = np.append(deviceLogsContent,[[row[4],datesSplicedValue,timeSplicedValue]])
        deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
        deviceLogsContent = deviceLogsContent.reshape(-1, 3)

        
        
for i in range(len(deviceLogsContent)-1):
    allEmployeeId = np.unique(deviceLogsContent[:,0])
    Dates_value = np.unique(deviceLogsContent[i,1])
    Dates_value_spliced = Dates_value[0][:8]    
    allDates.append(Dates_value_spliced)
    i += 1
allDates = np.unique(allDates)