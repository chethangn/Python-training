#         row[0] == Employee ID
#         row[1] == Employee Name
#         row[5] == Gender
#         row[8] == Designation
#         row[10] == DOJ

# Importing required libraries
import csv
import numpy as np
np.set_printoptions(threshold=np.inf)

# import collections
import matplotlib.pyplot as plt
import json
import re
import datetime

# Universal declarations to be used in function and outside
seen = []
name_column = 1
uniques = []

allEmployeeData = np.array([])
allEmployeeId = []
allDates = []
slice_content_days = np.array([])
deviceLogsContent = np.array([])
timingsLogs = np.array([])
formattedData = np.array([])
formattedData = np.append(formattedData,[['EmpID','EmpName','InTime','OutTime','Date']])
formattedData = formattedData.reshape((formattedData.shape[0], 1))
formattedData = formattedData.reshape(-1, 5)
year_male_count = []
count_2011 = 0
count = 0
month = []
year = []
year_val = []
month_val = []
i = 0 

# Function for checking out if name field contains number
def num_there(s):
    return any(i.isdigit() for i in s)


# Opening a csv file
with open('Employees_file.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    for row in inf:
        if row[name_column] not in seen and not (num_there(row[1])) and not row[5] == 'Gender':
            if row[5] == 'M' or row[5] == 'male':
                row[5] = 'Male'
            if row[5] == 'F' or row[5] == 'female':
                row[5] = 'Female'
            uniques.append(row)
            seen.append(row[name_column])
            row[10] = row[10][0:8]
            year_val = row[10][6:8]
            month_val = row[10][0:2]
            year.append(year_val)
            month.append(month_val)
            if re.match(r'^Del_', row[2]):
                row[2] = row[2][4:]
            allEmployeeData = np.append(allEmployeeData,[[row[2],row[1],row[5],row[10],row[8],month_val,year_val]])
            allEmployeeData = allEmployeeData.reshape((allEmployeeData.shape[0], 1))
            allEmployeeData = allEmployeeData.reshape(-1, 7)

            
# with open('DeviceLogs1.csv') as csvfile:
#     inf1 = csv.reader(csvfile, delimiter=',')
#     for row in inf1:
#         if num_there(row[0]):
#             datesSplicedValue = row[5][:8]
#             timeSplicedValue = row[5][9:17]
#             deviceLogsContent = np.append(deviceLogsContent,[[row[4],datesSplicedValue,timeSplicedValue]])
#             deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
#             deviceLogsContent = deviceLogsContent.reshape(-1, 3)

with open('DeviceLogs2.csv') as csvfile:
    inf1 = csv.reader(csvfile, delimiter=',')
    for row in inf1:
        if num_there(row[0]):
            datesSplicedValue = row[5][:8]
            timeSplicedValue = row[5][9:17]
            deviceLogsContent = np.append(deviceLogsContent,[[row[4],datesSplicedValue,timeSplicedValue]])
            deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
            deviceLogsContent = deviceLogsContent.reshape(-1, 3)
# print(deviceLogsContent)

# Unique Date and ID
allEmployeeDates = np.unique(deviceLogsContent[:,1])
allEmployeeID = np.unique(deviceLogsContent[:,0])

# Sorting
# x = np.sort(deviceLogsContent, axis=0)
i = np.lexsort((deviceLogsContent[:,0]))
x = deviceLogsContent[i]
# print(x.shape)
print(x)

# Length of dates and ID
allEmployeeDatesLength = len(allEmployeeDates)
allEmployeeIDLength = len(allEmployeeID)
lengthX = len(x)

newid = 1

for content in range(len(x)-1):
    if x[i,0] == x[i+1,0] and x[i,1] == x[i+1,1]:
        if newid == 1:
            formattedData = np.append(formattedData,[[x[i,0],'EmpName',x[i,2],x[i,2],x[i,1]]])
            formattedData = formattedData.reshape((formattedData.shape[0], 1))
            formattedData = formattedData.reshape(-1, 5)
            idappend = x[i,0]
            dateappend = x[i,1]
            timeappend = x[i,2]
            newid = 0
#     if x[i,0] != x[i+1,0] or x[i,1] != x[i+1,1]:
#         j = 0
#         for value in formattedData:
#             if formattedData[j,0] == x[i,0]:
#                 formattedData[j,3] = x[i,2]
#             j += 1
#         newid = 1
    if x[i,0] == x[i+1,0] and x[i,1] != x[i+1,1]:
#         if idappend == x[i,0] and dateappend == x[i,1] and timeappend != x[i,2]:
#             formattedData[i,3] = x[i,2]
        formattedData = np.append(formattedData,[[x[i,0],'EmpName',x[i,2],x[i,2],x[i,1]]])
        formattedData = formattedData.reshape((formattedData.shape[0], 1))
        formattedData = formattedData.reshape(-1, 5)
        newid = 1
    if x[i,0] != x[i+1,0] and x[i,1] == x[i+1,1]:
#         if idappend == x[i,0] and dateappend == x[i,1] and timeappend != x[i,2]:
#             formattedData[i,3] = x[i,2]
        formattedData = np.append(formattedData,[[x[i,0],'EmpName',x[i,2],x[i,2],x[i,1]]])
        formattedData = formattedData.reshape((formattedData.shape[0], 1))
        formattedData = formattedData.reshape(-1, 5)
        newid = 1
    if x[i,0] != x[i+1,0] and x[i,1] != x[i+1,1]:
#         if idappend == x[i,0] and dateappend == x[i,1] and timeappend != x[i,2]:
#             formattedData[i,3] = x[i,2]
        formattedData = np.append(formattedData,[[x[i,0],'EmpName',x[i,2],x[i,2],x[i,1]]])
        formattedData = formattedData.reshape((formattedData.shape[0], 1))
        formattedData = formattedData.reshape(-1, 5)
        newid = 1
    i += 1
# print(formattedData)
# print(x)
