import csv
import numpy as np
import datetime as dtm
from datetime import timedelta
import time
np.set_printoptions(threshold=np.inf)

timedata = np.array([])
timedata_male = np.array([])
timedata_female = np.array([])
timedata_other = np.array([])
ppl_leaving = np.array([])

#functions..
def num_there(s):
    return any(i.isdigit() for i in s)

# Opening a npy file..
data = np.array([])
data = np.load('formatted1Feb.npy')
print ('WELCOME to the analysis\n')
print ('Enter any of the following numbers for the respective action to be performed')

print ('1 -- Average Male in and out time from February till Aug')

print ('2 -- Average In and out time February')
print ('3 -- Average In and out time March')
print ('4 -- Average In and out time April')
print ('5 -- Average In and out time May')
print ('6 -- Average In and out time June')
print ('7 -- Average In and out time July')
print ('8 -- Average In and out time Aug')

print ('9 -- People leaving together')
action = input ('Select an action :')
print ('You have selected action',action,'to be performed')


if action == "1":
    data = np.load('formattedFull.npy')
    print("\n\n\tFull Analysis\n\n")
if action == "2":
    data = np.load('formatted1Feb.npy')
    print("\n\n\tFebruary Month Analysis\n\n")
if action == "3":
    data = np.load('formatted2Mar.npy')
    print("\n\n\tMarch Month Analysis\n\n")
if action == "4":
    data = np.load('formatted3Apr.npy')
    print("\n\n\tApril Month Analysis\n\n")
if action == "5":
    data = np.load('formatted4May.npy')
    print("\n\n\tMay Month Analysis\n\n")
if action == "6":
    data = np.load('formatted5Jun.npy')
    print("\n\n\tJune Month Analysis\n\n")
if action == "7":
    data = np.load('formatted6Jul.npy')
    print("\n\n\tJuly Month Analysis\n\n")
if action == "8":
    data = np.load('formatted7Aug.npy')
    print("\n\n\tAug Month Analysis\n\n")

i = -1

for row in range(len(data)):
    i += 1
    if num_there(data[i,0]):
        intime = data[i,2]
        outtime = data[i,3]
        InHour = float(intime[0:2])
        InMinutes = float(intime[3:5])
        InSeconds = float(intime[6:8])
        OutHour = float(outtime[0:2])
        OutMinutes = float(outtime[3:5])
        OutSeconds = float(outtime[6:8])
        Incovseconds = InHour * 3600 + InMinutes * 60 + InSeconds
        Outcovseconds = OutHour * 3600 + OutMinutes * 60 + OutSeconds
        if i < len(data)-1:
            intime_i = data[i+1,2]
            outtime_i = data[i+1,3]
            InHour_i = float(intime_i[0:2])
            InMinutes_i = float(intime_i[3:5])
            InSeconds_i = float(intime_i[6:8])
            OutHour_i = float(outtime_i[0:2])
            OutMinutes_i = float(outtime_i[3:5])
            OutSeconds_i = float(outtime_i[6:8])
            Incovseconds_i = InHour_i * 3600 + InMinutes_i * 60 + InSeconds_i
            Outcovseconds_i = OutHour_i * 3600 + OutMinutes_i * 60 + OutSeconds_i

    # Male avg in and out time
        if data[i,5] == 'Male':
            timedata_male = np.append(timedata_male,[[InHour,InMinutes,InSeconds,OutHour,OutMinutes,OutSeconds,Incovseconds,Outcovseconds]])
            timedata_male = timedata_male.reshape((timedata_male.shape[0], 1))
            timedata_male = timedata_male.reshape(-1, 8)

    # Female avg in and out time
        if data[i,5] == 'Female':
            timedata_female = np.append(timedata_female,[[InHour,InMinutes,InSeconds,OutHour,OutMinutes,OutSeconds,Incovseconds,Outcovseconds]])
            timedata_female = timedata_female.reshape((timedata_female.shape[0], 1))
            timedata_female = timedata_female.reshape(-1, 8)

    # Other avg in and out time
        if data[i,5] != 'Female' and data[i,5] != 'Male':
            timedata_other = np.append(timedata_other,[[InHour,InMinutes,InSeconds,OutHour,OutMinutes,OutSeconds,Incovseconds,Outcovseconds]])
            timedata_other = timedata_other.reshape((timedata_other.shape[0], 1))
            timedata_other = timedata_other.reshape(-1, 8)

        timedata = np.append(timedata,[[InHour,InMinutes,InSeconds,OutHour,OutMinutes,OutSeconds,Incovseconds,Outcovseconds]])
        timedata = timedata.reshape((timedata.shape[0], 1))
        timedata = timedata.reshape(-1, 8)

# Average Time in and out calculations
# print(timedata[:,6])
average_time_in_seconds = np.average(timedata[:,6])
average_time_in_format = time.strftime("%H:%M:%S", time.gmtime(average_time_in_seconds))
average_time_out_seconds = np.average(timedata[:,7])
average_time_out_format = time.strftime("%H:%M:%S", time.gmtime(average_time_out_seconds))

# Avg male and female in and out timings
average_time_in_seconds_male = np.average(timedata_male[:,6])
average_time_in_format_male = time.strftime("%H:%M:%S", time.gmtime(average_time_in_seconds_male))
average_time_out_seconds_male = np.average(timedata_male[:,7])
average_time_out_format_male = time.strftime("%H:%M:%S", time.gmtime(average_time_out_seconds_male))

# Avg female in and out timings
average_time_in_seconds_female = np.average(timedata_female[:,6])
average_time_in_format_female = time.strftime("%H:%M:%S", time.gmtime(average_time_in_seconds_female))
average_time_out_seconds_female = np.average(timedata_female[:,7])
average_time_out_format_female = time.strftime("%H:%M:%S", time.gmtime(average_time_out_seconds_female))

# Average other in and out timings
average_time_in_seconds_other = np.average(timedata_other[:,6])
average_time_in_format_other = time.strftime("%H:%M:%S", time.gmtime(average_time_in_seconds_other))
average_time_out_seconds_other = np.average(timedata_other[:,7])
average_time_out_format_other = time.strftime("%H:%M:%S", time.gmtime(average_time_out_seconds_other))

print("Average in time",average_time_in_format)
print("Average out time",average_time_out_format)

print("\nAverage in time male-----",average_time_in_format_male)
print("Average out time male----",average_time_out_format_male)

print("\nAverage in time female---- ",average_time_in_format_female)
print("Average out time female----",average_time_out_format_female)

print("\nAverage in time other---- ",average_time_in_format_other)
print("Average out time other----",average_time_out_format_other)
# print(data[0,1])
# print(timedata[0])
