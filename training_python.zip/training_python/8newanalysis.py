import csv
import re
import numpy as np
import pandas as pd

# with open("output_file.csv", 'r') as f:

# with open("output_file.csv", 'r') as f:
#     wines = list(csv.reader(f, delimiter=";"))
# print(wines[:3])

# qualities = [float(item[-1]) for item in wines[1:]]
# sum(qualities) / len(qualities)

# wines = np.array(wines[1:], dtype=np.object)
# print(wines)




# wines = np("output_file.csv", delimiter=";", skip_header=1)
# print(wines)

# inf = csv.reader(open('output_file.csv','r'))
# inf = np.inf
# print(inf)
# -------------------------------------------------------------

# wines = np.genfromtxt("output_file.csv", delimiter="\t", skip_header=1)
# print(wines)
# ----------------------------------------------------------------------
a = np.genfromtxt("output_file.csv", delimiter='\t', dtype=None)
# np.split(a,74)
# print(a[6])
print(a)
# ------------------------------------------------------------------------
# s = str(a[1])
# print(re.split(r"",s))
# ----------------------------------------------------------------------------
# print(s)
# print(a)
# -------------------------------------------------------------------------(reshape...)
# B = np.reshape(a , (-1, 2))
# print(B[1,1])
# ---------------------------------------------------------------------------
# b = np.reshape(a,(-1,73))
# a.shape = (a.size//74, 74)
# a = np.array(a,np.float32).reshape(1, len(a))




# -----------------------
# df = pd.read_csv("output_file.csv")
# # print(a[5:6])
# # print(df)
# test= df.groupby(['Gender'])
# print(test)

#---------------------------
