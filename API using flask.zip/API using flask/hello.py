__author__ = 'Chethan Kumar G N'

from flask import Flask, request
import csv
import matplotlib.pyplot as plt
import json
import re
import datetime
import numpy as np
np.set_printoptions(threshold=np.inf)
import matplotlib.pyplot as plt
import json
import re
import datetime
name_column = 1
seen = []
uniques = []
i = 0
year = []
month = []

app = Flask(__name__)

def num_there(s):
    return any(i.isdigit() for i in s)
@app.route('/')
def hello_world():
    return 'Hello ------ World!'

@app.route('/chart')
def barchart():
    a = np.array([])
    c = np.array([])
    with open('Employees_file.csv') as csvfile:
        inf = csv.reader(csvfile, delimiter=',')
        for row in inf:
            if row[name_column] not in seen and not (num_there(row[1])) and not row[5] == 'Gender':
                if row[5] == 'M' or row[5] == 'male':
                    row[5] = 'Male'
                if row[5] == 'F' or row[5] == 'female':
                    row[5] = 'Female'
                uniques.append(row)
                seen.append(row[name_column])
                row[10] = row[10][0:8]
                year_val = row[10][6:8]
                month_val = row[10][0:2]
                year.append(year_val)
                month.append(month_val)
                if re.match(r'^Del_', row[2]):
                    row[2] = row[2][4:]
                a = np.append(a,[[row[2],row[1],row[5],row[10],row[8],month_val,year_val]])
                a = a.reshape((a.shape[0], 1))
                a = a.reshape(-1, 7)
    with open('DeviceLogs1.csv') as csvfile:
        inf1 = csv.reader(csvfile, delimiter=',')
        for row in inf1:
            c = np.append(c,[[row[4],row[5]]])
            c = c.reshape((c.shape[0], 1))
            c = c.reshape(-1, 2)
    with open('DeviceLogs2.csv') as csvfile:
        inf1 = csv.reader(csvfile, delimiter=',')
        for row in inf1:
            c = np.append(c,[[row[4],row[5]]])
            c = c.reshape((c.shape[0], 1))
            c = c.reshape(-1, 2)
    with open('DeviceLogs3.csv') as csvfile:
        inf1 = csv.reader(csvfile, delimiter=',')
        for row in inf1:
            c = np.append(c,[[row[4],row[5]]])
            c = c.reshape((c.shape[0], 1))
            c = c.reshape(-1, 2)
    with open('DeviceLogs4.csv') as csvfile:
        inf1 = csv.reader(csvfile, delimiter=',')
        for row in inf1:
            c = np.append(c,[[row[4],row[5]]])
            c = c.reshape((c.shape[0], 1))
            c = c.reshape(-1, 2)
    with open('DeviceLogs5.csv') as csvfile:
        inf1 = csv.reader(csvfile, delimiter=',')
        for row in inf1:
            c = np.append(c,[[row[4],row[5]]])
            c = c.reshape((c.shape[0], 1))
            c = c.reshape(-1, 2)
    with open('DeviceLogs6.csv') as csvfile:
        inf1 = csv.reader(csvfile, delimiter=',')
        for row in inf1:
            c = np.append(c,[[row[4],row[5]]])
            c = c.reshape((c.shape[0], 1))
            c = c.reshape(-1, 2)
    with open('DeviceLogs7.csv') as csvfile:
        inf1 = csv.reader(csvfile, delimiter=',')
        for row in inf1:
            c = np.append(c,[[row[4],row[5]]])
            c = c.reshape((c.shape[0], 1))
            c = c.reshape(-1, 2) 
    return 'Hello ------ World!'

@app.route('/test')
def test():
    allEmployeeData = np.array([])
    formattedData = np.array([])
    sortedarray = np.array([])
    deviceLogsContent = np.array([])
    with open('Employees_file.csv') as csvfile:
        inf = csv.reader(csvfile, delimiter=',')
        for row in inf:
            if row[name_column] not in seen and not (num_there(row[1])) and not row[5] == 'Gender':
                if row[5] == 'M' or row[5] == 'male':
                    row[5] = 'Male'
                if row[5] == 'F' or row[5] == 'female':
                    row[5] = 'Female'
                uniques.append(row)
                seen.append(row[name_column])
                row[10] = row[10][0:8]
                year_val = row[10][6:8]
                month_val = row[10][0:2]
                year.append(year_val)
                month.append(month_val)
                if re.match(r'^Del_', row[2]):
                    row[2] = row[2][4:]
                allEmployeeData = np.append(allEmployeeData,[[row[2],row[1],row[5],row[10],row[8],month_val,year_val]])
                allEmployeeData = allEmployeeData.reshape((allEmployeeData.shape[0], 1))
                allEmployeeData = allEmployeeData.reshape(-1, 7)
    with open('DeviceLogs1.csv') as csvfile:
        inf1 = csv.reader(csvfile, delimiter=',')
        for row in inf1:
            if num_there(row[0]):
                datesSplicedValue = row[5][:8]
                timeSplicedValue = row[5][9:17]
                deviceLogsContent = np.append(deviceLogsContent,[[row[4],datesSplicedValue,timeSplicedValue]])
                deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
                deviceLogsContent = deviceLogsContent.reshape(-1, 3)
    with open('DeviceLogs2.csv') as csvfile:
        inf1 = csv.reader(csvfile, delimiter=',')
        for row in inf1:
            if num_there(row[0]):
                datesSplicedValue = row[5][:8]
                timeSplicedValue = row[5][9:17]
                deviceLogsContent = np.append(deviceLogsContent,[[row[4],datesSplicedValue,timeSplicedValue]])
                deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
                deviceLogsContent = deviceLogsContent.reshape(-1, 3)
    with open('DeviceLogs3.csv') as csvfile:
        inf1 = csv.reader(csvfile, delimiter=',')
        for row in inf1:
            if num_there(row[0]):
                datesSplicedValue = row[5][:8]
                timeSplicedValue = row[5][9:17]
                deviceLogsContent = np.append(deviceLogsContent,[[row[4],datesSplicedValue,timeSplicedValue]])
                deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
                deviceLogsContent = deviceLogsContent.reshape(-1, 3)
    with open('DeviceLogs4.csv') as csvfile:
        inf1 = csv.reader(csvfile, delimiter=',')
        for row in inf1:
            if num_there(row[0]):
                datesSplicedValue = row[5][:8]
                timeSplicedValue = row[5][9:17]
                deviceLogsContent = np.append(deviceLogsContent,[[row[4],datesSplicedValue,timeSplicedValue]])
                deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
                deviceLogsContent = deviceLogsContent.reshape(-1, 3)
    with open('DeviceLogs5.csv') as csvfile:
        inf1 = csv.reader(csvfile, delimiter=',')
        for row in inf1:
            if num_there(row[0]):
                datesSplicedValue = row[5][:8]
                timeSplicedValue = row[5][9:17]
                deviceLogsContent = np.append(deviceLogsContent,[[row[4],datesSplicedValue,timeSplicedValue]])
                deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
                deviceLogsContent = deviceLogsContent.reshape(-1, 3)
    with open('DeviceLogs6.csv') as csvfile:
        inf1 = csv.reader(csvfile, delimiter=',')
        for row in inf1:
            if num_there(row[0]):
                datesSplicedValue = row[5][:8]
                timeSplicedValue = row[5][9:17]
                deviceLogsContent = np.append(deviceLogsContent,[[row[4],datesSplicedValue,timeSplicedValue]])
                deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
                deviceLogsContent = deviceLogsContent.reshape(-1, 3)
    with open('DeviceLogs7.csv') as csvfile:
        inf1 = csv.reader(csvfile, delimiter=',')
        for row in inf1:
            if num_there(row[0]):
                datesSplicedValue = row[5][:8]
                timeSplicedValue = row[5][9:17]
                deviceLogsContent = np.append(deviceLogsContent,[[row[4],datesSplicedValue,timeSplicedValue]])
                deviceLogsContent = deviceLogsContent.reshape((deviceLogsContent.shape[0], 1))
                deviceLogsContent = deviceLogsContent.reshape(-1, 3)
    lenformattedData = len(formattedData) - 1
    formattedData[lenformattedData,3] = sortedarray[i,2]
    x = -1
    y = -1
    while x < len(formattedData)-1:
        x += 1
        while y < len(allEmployeeData)-1:
            y += 1
            if formattedData[x,0] == allEmployeeData[y,0]:
                formattedData[x,1] = allEmployeeData[y,1]
                formattedData[x,5] = allEmployeeData[y,2]
        y = 0
    formattedData[lenformattedData,1] = formattedData[lenformattedData-1,1]
    list = [
        {'a': 1, 'b': 2},
        {'a': 5, 'b': 10}
       ]
    return json.dumps(list)

if __name__ == '__main__':
    app.run(host='127.0.0.1',port=8000,debug=True)


