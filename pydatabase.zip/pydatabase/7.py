import numpy as np
import pandas as pd
import csv



print ('Welcome to database analysis')


inf = csv.reader(open('output_file.csv','r'))
# inf = csv.reader(open('output_file.csv','r'))
for row in inf:
    rowx = row[10]
    rowy = row[2:3]
    # print (rowy)
