from __future__ import print_function
import csv
import numpy as np
import re

r = re.compile('^\d{2}/\d{2}/\d{2} T\d{2}:\d{2}:\d{2}\+\d{2}')
a=0
b=0
arr1DOJfull = []
arr2DOJyear = []
arr3DOJmonth = []
male2011 = 0
male2012 = 0
year_2011male = 0
year_2011female = 0
with open('output_file.csv') as csvfile:
    inf = csv.reader(csvfile, delimiter=',')
    for row in inf:
        if row[5] == 'M' or row[5] == 'Male' or row[5] == 'M' or row[5] == 'male' and r.match(row[10]):
            DOJrow = row[10]
            spliceDOJrowmale = DOJrow[7:8]
            if spliceDOJrowmale == 11:
                year_2011male += 1
        if row[5] == 'F' or row[5] == 'Female' or row[5] == 'f' or row[5] == 'female' and r.match(row[10]):
            DOJrow = row[10]
            spliceDOJrowfemale = DOJrow[6:8]
            if spliceDOJrowfemale == 11:
                year_2011female += 1
print (year_2011male,year_2011female)
