from __future__ import print_function
import csv
import numpy as np
import re
a = 0
b = 0
DOJrow = 0
count2011 = 0
male_array_year = [0,0,0,0,0,0,0]
female_array_year = [0,0,0,0,0,0,0]
junk=0
i=2011
j=2011
totalmale = 0
totalfemale = 0
def yearcount( year, sex ):
    year = year
    sex = sex
    if sex == 1:
        if year == '00':
            junk=0
        if year == '11':
            male_array_year[0] += 1
        if year == '12':
            male_array_year[1] += 1
        if year == '13':
            male_array_year[2] += 1
        if year == '14':
            male_array_year[3] += 1
        if year == '15':
            male_array_year[4] += 1
        if year == '16':
            male_array_year[5] += 1
        if year == '17':
            male_array_year[6] += 1
        # else:
        #     junk += 1
    if sex == '00':
        if year == '11':
            female_array_year[0] += 1
        if year == '12':
            female_array_year[1] += 1
        if year == '13;:
            female_array_year[2] += 1
        if year == '14':
            female_array_year[3] += 1
        if year == '15':
            female_array_year[4] += 1
        if year == '16':
            female_array_year[5] += 1
        if year == '17':
            female_array_year[6] += 1

    return male_array_year,female_array_year;

print ('WELCOME to the database analysis\n')
print ('Enter any of the following numbers')
print ('1 -- Total emplyee count')
print ('2 -- Total male and female employee count')
print ('3 -- Male and Female count based on yearly basis')
print ('4 -- Male and Female count based on monthly basis')
action = input ('Select an action :')

if action >= 1 and action <= 2:
    print ('You have selected action',action,'to be performed')
    inf = csv.reader(open('output_file.csv','r'))
    for row in inf:
      if row[5] == 'M' or row[5] == 'Male' or row[5] == 'm' or row[5] == 'male':
          a += 1
      if row[5] == 'F' or row[5] == 'Female' or row[5] == 'f' or row[5] == 'female':
          b += 1
    if action == 1:
        c = a+b
        print ('Total number of employees till hired are:',c)
    if action == 2:
        print ("No of male employees hired till date are:",a)
        print ("No of female employees hired till date are:",b)
elif action == 3:
    print ('You have selected action',action,'to be performed')
    inf = csv.reader(open('output_file.csv','r'))
    for row in inf:
        if row[5] == 'M' or row[5] == 'Male' or row[5] == 'm' or row[5] == 'male':
# Here 1 represents male
            sex = 1;
            DOJrow = row[10]
            year = DOJrow[6:8]
            yearcount(year=year,sex=sex)
        if row[5] == 'F' or row[5] == 'Female' or row[5] == 'f' or row[5] == 'female':
# Here 0 represents female
            sex = 0;
            DOJrow = row[10]
            year = DOJrow[6:8]
            yearcount(year=year,sex=sex)
        else:
            junk += 1
    for valuemale in male_array_year:
        totalmale = valuemale + totalmale
        print ('Male count hired in',i,'is',valuemale)
        print ('Total',totalmale)
        i = i+1
    for valuefemale in female_array_year:
        totalfemale = valuefemale + totalfemale
        print ('Female count hired in',j,'is',valuefemale)
        print ('Total',totalfemale)
        j = j+1
    print ('Total male employees is',totalmale)
    print ('Total female employess is',totalfemale)
else:
    print ('Enter proper action to be performed')
