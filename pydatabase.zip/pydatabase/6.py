import pandas as pd
import matplotlib.pyplot as plt
# Matrix = [[0 for x in range(w)] for y in range(h)]
information = pd.read_csv('output_file.csv', parse_dates=True)
inf = information.head(n=5)
print ('WELCOME to the database analysis\n')
print ('Enter any of the following numbers')
print ('1 -- Employee based department count')
action = input ('Select an action :')
print ('You have selected action',action,'to be performed')
array = inf[['Designation','Remarks','DepartmentId']]
arr = information.groupby('Remarks')['DepartmentId'].plot()
# print (array)
print (arr)

%matplotlib inline
