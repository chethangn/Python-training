# import numpy as np
# from numpy import genfromtxt
# my_data = np.genfromtxt('output_file.csv', delimiter=',')
# import pandas as pd
# df=pd.read_csv('myfile.csv' , sep=',' , header=None)
import numpy as np
data = np.genfromtxt('output_file.csv', comments='#', delimiter='\t', names=True, dtype=None).transpose()
print(data.shape)
